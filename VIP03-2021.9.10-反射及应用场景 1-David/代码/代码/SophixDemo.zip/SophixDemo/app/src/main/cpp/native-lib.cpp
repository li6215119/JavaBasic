#include <jni.h>
#include <string>
#include "art_method.h"
extern "C" JNIEXPORT jstring JNICALL
Java_com_maniu_sophixmaniu_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}extern "C"
JNIEXPORT void JNICALL
Java_com_maniu_sophixdemo_DexManager_replace(JNIEnv *env, jclass clazz, jobject wrongMethod,
                                             jobject rightMethod) {

//    method   对象    -----》 方发表中 Artmethod
//
//native 层有反射  有1  没有2
    art::mirror::ArtMethod  *wrong  = reinterpret_cast<art::mirror::ArtMethod *>(env->FromReflectedMethod(
            wrongMethod));


    art::mirror::ArtMethod  *right = reinterpret_cast<art::mirror::ArtMethod *>(env->FromReflectedMethod(
            rightMethod));
//能1  不能2
//    wrong = right;
    wrong->declaring_class_ = right->declaring_class_;
    wrong->access_flags_ = right->access_flags_;
    wrong->dex_code_item_offset_ = right->dex_code_item_offset_;
    wrong->dex_method_index_ = right->dex_method_index_;
    wrong->method_index_ = right->method_index_;
    wrong->hotness_count_ = right->hotness_count_;

    wrong->ptr_sized_fields_.dex_cache_resolved_methods_ =
            right->ptr_sized_fields_.dex_cache_resolved_methods_;
    wrong->ptr_sized_fields_.dex_cache_resolved_types_ =
            right->ptr_sized_fields_.dex_cache_resolved_types_;

    wrong->ptr_sized_fields_.entry_point_from_jni_ =
            right->ptr_sized_fields_.entry_point_from_jni_;
    wrong->ptr_sized_fields_.entry_point_from_quick_compiled_code_ =
            right->ptr_sized_fields_.entry_point_from_quick_compiled_code_;
// 替换Artmethod
}