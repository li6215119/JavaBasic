package com.maniu.sophixdemo;

public class Caclutor {

	public int cacultor() {
//		模拟 大写代码不严谨
		throw new RuntimeException(" 不好意思   代码没写好  出现了异常我奔溃了");
	}
}
