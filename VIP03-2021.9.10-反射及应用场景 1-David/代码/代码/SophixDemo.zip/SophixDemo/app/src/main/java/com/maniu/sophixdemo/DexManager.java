package com.maniu.sophixdemo;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Enumeration;

import dalvik.system.DexClassLoader;
import dalvik.system.DexFile;

//加载机制 加载修复包
public class DexManager {

    private Context context;
    static {
        System.loadLibrary("native-lib");
    }
    public DexManager(Context context) {
        this.context = context;
    }

    public void load(File file) {
        try {
            DexFile dexFile = DexFile.loadDex(file.getAbsolutePath(),
                    new File(context.getCacheDir(), "opt")
                            .getAbsolutePath(), Context.MODE_PRIVATE);

            Enumeration<String> entry = dexFile.entries();
            while (entry.hasMoreElements()) {
                String className =  entry.nextElement();
//                Class realClazz =  Class.forName(className);
//                能1  不能 2
                Class realClazz;
                realClazz = dexFile.loadClass(className, context.getClassLoader());
                if (realClazz != null) {

                    fixClazz(realClazz);

                }
            }
        } catch ( Exception e) {
            e.printStackTrace();
        }
    }

//    执行  一次      反射
    private void fixClazz(Class realClazz) {
        Method[] methods = realClazz.getMethods();

        for (Method rightMethod : methods) {
            Replace replace=rightMethod.getAnnotation(Replace.class);
            if (replace == null) {
                continue;
            }

            String clazzName = replace.clazz();
            String methodName = replace.method();
//            能1      不能2
            try {
                Class wrongClazz = Class.forName(clazzName);
                Log.i("tuch", "fixClazz:====> "+rightMethod);
                Log.i("tuch", "methodName:====> "+methodName);
                Method wrongMethod =  wrongClazz.getDeclaredMethod(methodName, rightMethod.getParameterTypes());
                replace(wrongMethod, rightMethod);
            } catch ( Exception e) {
                e.printStackTrace();
            }
        }



    }

    public native static void replace(Method wrongMethod, Method rightMethod);
//   先查找 方法区中的Artmethod     在来做替换
static {
    System.loadLibrary("native-lib");
}

}
