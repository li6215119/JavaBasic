package com.maniu.sophixdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.media.MediaCodec;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.io.File;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        verifyStoragePermissions(this );
//        区别 1  不 深面试  开发   高级
        textView = (TextView) findViewById(R.id.result);
        MediaCodec.createDecoderByType()
    }
    public   void verifyStoragePermissions(Activity activity) {
        int REQUEST_EXTERNAL_STORAGE = 1;
        String[] PERMISSIONS_STORAGE = {
                "android.permission.READ_EXTERNAL_STORAGE",
                "android.permission.WRITE_EXTERNAL_STORAGE" };
        try {
            //检测是否有写的权限
            int permission = ActivityCompat.checkSelfPermission(activity,
                    "android.permission.WRITE_EXTERNAL_STORAGE");
            if (permission != PackageManager.PERMISSION_GRANTED) {
                // 没有写的权限，去申请写的权限，会弹出对话框
                ActivityCompat.requestPermissions(activity, PERMISSIONS_STORAGE,REQUEST_EXTERNAL_STORAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void caclutor(View view) {
        Caclutor caclutor = new Caclutor();
        Caclutor caclutor1 = new Caclutor();
        Caclutor caclutor2 = new Caclutor();
        Caclutor caclutor3 = new Caclutor();
        textView.setText("结果:" + caclutor.cacultor()+"   结果:  " + caclutor1.cacultor()+"   结果:  " + caclutor2.cacultor()+"   结果:  " + caclutor3.cacultor());
    }

}