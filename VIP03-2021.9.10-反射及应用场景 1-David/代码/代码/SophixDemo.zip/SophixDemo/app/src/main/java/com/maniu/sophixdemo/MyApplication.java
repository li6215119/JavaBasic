package com.maniu.sophixdemo;

import android.app.Application;
import android.os.Environment;

import java.io.File;

public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

        File file = new File(Environment.getExternalStorageDirectory(), "out.dex");
//        在
        if (file.exists()) {
            DexManager dexManager = new DexManager(this);
            dexManager.load(file);
        }
    }
}
