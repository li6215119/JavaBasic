package com.maniu.sophixdemo;

public class Person {
}
