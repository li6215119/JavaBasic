package com.maniu.maniu;

public class MyClass {
    private  volatile  boolean flag = false;
    public  void test() throws Exception {
        new Thread() {
            @Override
            public void run() {
                System.out.println("Thread1--start");
                while (!flag) {
//                    视频解码  死循环
                }
                System.out.println("Thread1--end");
            }
        }.start();
        Thread.sleep(100);
        new Thread() {
            @Override
            public void run() {
                System.out.println("Thread2--start");
                flag = true;
                System.out.println("Thread2--end");
            }
        }.start();
    }
//   System.out.println("Thread1--end");
//    能1  Thread1--end

//    不能打印 2
    public static void main(String[] args) throws Exception {
        MyClass myClass = new MyClass();
        myClass.test();
    }


}