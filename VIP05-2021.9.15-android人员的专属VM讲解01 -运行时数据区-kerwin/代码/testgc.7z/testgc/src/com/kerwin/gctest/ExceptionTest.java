package com.kerwin.gctest;

import java.io.FileReader;
import java.io.IOException;

public class ExceptionTest {


    private void method4() {

        try{
            FileReader fr = new FileReader("test.txt");

            char[] b = new char[4096];
            int length = -1;
            while((length = fr.read(b)) > 0){
                String s = new String(b);
            }
        }catch (IOException e){
            e.printStackTrace();
        }

    }

}
