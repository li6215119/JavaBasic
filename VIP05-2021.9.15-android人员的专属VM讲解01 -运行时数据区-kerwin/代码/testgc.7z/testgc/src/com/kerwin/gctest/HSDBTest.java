package com.kerwin.gctest;

public class HSDBTest {

    public static void main(String[] args) {
        Teacher kerwin = new Teacher();
        kerwin.setName("kerwin");

        for (int i = 0; i < 15; i++) {
            System.gc();
        }

        Teacher jett = new Teacher();
        jett.setName("jett");
        StackTest test = new StackTest();
        test.test1(1);
        System.out.println("挂起....");
        try {
            Thread.sleep(10000000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }





}
