package com.kerwin.gctest;

public class MethodAreaDemo {

    private int age;
    private Person person;

    public void test1(){
        int i = 10;
        int m = 20;
        int k = (i +m) * 10;
        Person p = new Person();
        double a = k * 10;
        int b = 5;
        p.setAge(a);
        method1(1);

    }

    private static void method1(int i) {
        int result = i* 10;
    }

    private void method2(int i,int j) {

        try{
            int result = i / j;
        }catch (Exception e){
            e.printStackTrace();
        }
    }


}
