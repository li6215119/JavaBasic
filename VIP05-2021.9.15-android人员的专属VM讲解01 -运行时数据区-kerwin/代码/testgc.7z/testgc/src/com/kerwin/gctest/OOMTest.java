package com.kerwin.gctest;

public class OOMTest {

    public static void main(String[] args) {
        new OOMTest().stackOOM();
    }

    /**
     * 线程开辟过多导致物理内存分配不了
     */
    public void stackOOM(){

        for (;;){
            Thread t = new Thread(()->{
                try {
                    Thread.sleep(1000000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });
            t.start();
        }

    }


}
