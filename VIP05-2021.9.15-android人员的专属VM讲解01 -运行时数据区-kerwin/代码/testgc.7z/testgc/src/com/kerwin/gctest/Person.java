package com.kerwin.gctest;

public class Person {
    public double getAge() {
        return age;
    }

    public void setAge(double age) {
        this.age = age;
    }

    private double age;

}
