package com.kerwin.gctest;

import java.io.FileReader;
import java.io.IOException;

public class StackTest {
    public static void main(String[] args) {

        StackTest test = new StackTest();
        test.test1(1);
        System.out.println("挂起....");
        try {
            Thread.sleep(10000000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    /**
     * jclasslib 局部变量表分析案例
     */
    public void test1(int kerwin){
        //局部变量表
        //JAVA变量类型：值类型、引用类型
        //栈里面放值类型与引用类型的内存地址-->局部变量表

        byte i = 10;
        int m = 20;
        int k = (i +m) * 10;
        Person p = new Person();
        double a = k * 10;
        int b = 5;
        p.setAge(a);
        method1();

    }


    /**
     * slot重复利用案例
     */
    public static void method1(){
        int a = 0;
        {
            int b = 0;
            b = a + 1;
        }
        int c = a + 1;
    }


    public void work1(){
        int a = 10;
        int b = 20;
        work2();
    }
    public void work2(){
        int c =30;
        int d = 40;
        work1();
    }


    public void method2(){
        int i = 10;
        int j = 15;
        int k = i + j;
    }


    public void method3(){
        try{
            method4();
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    private void method4() throws IOException {

        FileReader fr = new FileReader("test.txt");

        char[] b = new char[4096];
        int length = -1;
        while((length = fr.read(b)) > 0){
            String s = new String(b);
        }

    }
}
