package com.kerwin.gctest;

public class Teacher {


    private String name;

    private int age;

    public String getName() {

        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
