package com.kerwin.gctest;

import java.util.ArrayList;
import java.util.Date;

public class Test {
    public static void main(String[] args) {
//        ArrayList list = new ArrayList();
//        for (;;){
//            list.add(new TestGc());
//            try {
//                Thread.sleep(200000);
//            }catch (InterruptedException e){
//                e.printStackTrace();
//            }
//        }

        TestGc testGc = new TestGc();
        try {
            Thread.sleep(200000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


    }

    public static void test1(){
        Date date = new Date();
        String name1 = "admin";
        test2(date,name1);
    }

    public static void test2(Date p_date,String name2){
        p_date = null;
        name2 = "kerwin";
    }


    public int  work(){

        int x = 3;
        int y = 5;
        int z = (x+y) *10;
        return y;


    }


    public  void test3 (){
        int a = 0;
        {
            int b = 0;
            b = a+ 1;
        }
        int  c = a + 1;
    }

}
