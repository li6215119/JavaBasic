package com.kerwin.gctest;

public class Test2 {

    public static void main(String[] args) {
        new Test2().test1();
    }

    public void test1(){
        int i = 10;
        int j = 20;
        int k = (i + j) * 10;
    }


}
