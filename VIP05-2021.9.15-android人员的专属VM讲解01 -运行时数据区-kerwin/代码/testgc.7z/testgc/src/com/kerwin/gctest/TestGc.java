package com.kerwin.gctest;

public class TestGc {
    //300K
    byte b[] = new byte[300*1024];
}
