package com.kerwin.jvm02;

import java.util.ArrayList;

public class EdenSurvivorTest {

    public static void main(String[] args) {
        EdenSurvivorTest test = new EdenSurvivorTest();
//        test.method1();
        test.method2();
    }

    /**
     * 堆内存大小示例
     * 默认空间大小：
     *  初始大小：物理电脑内存大小 / 64
     *  最大内存大小：物理电脑内存大小 / 4
     */
    public void method1(){
        long initialMemory = Runtime.getRuntime().totalMemory();
        long maxMemory = Runtime.getRuntime().maxMemory();
        System.out.println("初始内存："+(initialMemory / 1024 / 1024));
        System.out.println("最大内存："+(maxMemory / 1024 / 1024));


        try {
            Thread.sleep(100000000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }



    public void method2(){
        ArrayList list = new ArrayList();
        for (;;) {
            TestGC t = new TestGC();
//            list.add(t);
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }


    }


}
