package com.kerwin.jvm02;

import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

public class EscapeTest {


    Point p ;

    /**
     * 未发生逃逸
     */
    public void method1(){
        Point p = new Point();
        //............
        p = null;
    }

    /**
     * 产生逃逸
     */
    public static StringBuffer method2(String s1,String s2){
        StringBuffer sb = new StringBuffer();
        sb.append(s1);
        sb.append(s2);
        return sb;
    }
    /**
     * 未产生逃逸
     */
    public static String method3(String s1,String s2){
        StringBuffer sb = new StringBuffer();
        sb.append(s1);
        sb.append(s2);
        return sb.toString();
    }

    /**
     * 产生逃逸
     */
    public void method4(){
        p = new Point();
    }

    public void method5(Point p){

    }

    /**
     * 产生逃逸
     */
    public void method6(){
        Point p = new Point();
        method5(p);
    }


    /**
     * 逃逸分析，站上分配与标量替换
     * -Xmx1G -Xms1G -XX:-DoEscapeAnalysis -XX:+PrintGCDetails
     * -Xmx1G -Xms1G -XX:-EliminateAllocations -XX:+PrintGCDetails
     * @param args
     */
    public static void main(String[] args) {
        long start = System.currentTimeMillis();
        for (int i = 0; i < 100000000; i++) {
            alloc();
        }
        long end = System.currentTimeMillis();
        System.out.println("运行时间："+(end - start));
        try {
            Thread.sleep(10000000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void alloc(){
        Point p = new Point();
        int x = 0;
        int y = 0;
    }











}
