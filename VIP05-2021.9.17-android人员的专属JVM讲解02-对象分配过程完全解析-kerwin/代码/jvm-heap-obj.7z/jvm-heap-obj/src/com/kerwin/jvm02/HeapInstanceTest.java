package com.kerwin.jvm02;


public class HeapInstanceTest {
}
