package com.kerwin.jvm02;

public class MeasureSpec {
    private static final int MODE_SHIFT = 30;
    private static final int MODE_MASK  = 0x3 << MODE_SHIFT;
    /**
     * UNSPECIFIED 模式：
     * 父View不对子View有任何限制，子View需要多大就多大
     */
    public static final int UNSPECIFIED = 0 << MODE_SHIFT;

    /**
     * EXACTYLY 模式：
     * 父View已经测量出子Viwe所需要的精确大小，这时候View的最终大小
     * 就是SpecSize所指定的值。对应于match_parent和精确数值这两种模式
     */
    public static final int EXACTLY     = 1 << MODE_SHIFT;

    /**
     * AT_MOST 模式：
     * 子View的最终大小是父View指定的SpecSize值，并且子View的大小不能大于这个值，
     * 即对应wrap_content这种模式
     */
    public static final int AT_MOST     = 2 << MODE_SHIFT;
    private static boolean sUseBrokenMakeMeasureSpec;

    //将size和mode打包成一个32位的int型数值
    //高2位表示SpecMode，测量模式，低30位表示SpecSize，某种测量模式下的规格大小
    public static int makeMeasureSpec(int size, int mode) {
        if (sUseBrokenMakeMeasureSpec) {
            return size + mode;
        } else {
            return (size & ~MODE_MASK) | (mode & MODE_MASK);
        }
    }

    //将32位的MeasureSpec解包，返回SpecMode,测量模式
    public static int getMode(int measureSpec) {
        return (measureSpec & MODE_MASK);
    }

    //将32位的MeasureSpec解包，返回SpecSize，某种测量模式下的规格大小
    public static int getSize(int measureSpec) {
        return (measureSpec & ~MODE_MASK);
    }
    //...
}
