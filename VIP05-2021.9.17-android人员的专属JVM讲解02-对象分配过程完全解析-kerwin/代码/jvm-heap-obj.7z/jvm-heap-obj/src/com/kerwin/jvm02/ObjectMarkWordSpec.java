package com.kerwin.jvm02;

public class ObjectMarkWordSpec {

    private static final int LOCK_HASHCODE  = 0x1 << 32 ;
    private static final int LOCK_AGE  = 0x1 << 32-25 ;
    private static final int AGE  =  0x1 << 32-25-4;
    private static final int LOCK_STATUS  = 0x1 << 32-25-4-1 ;


}
