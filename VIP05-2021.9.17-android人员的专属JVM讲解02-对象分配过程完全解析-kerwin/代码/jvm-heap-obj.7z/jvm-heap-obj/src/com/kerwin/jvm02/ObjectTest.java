package com.kerwin.jvm02;

public class ObjectTest {


    public static void main(String[] args) {
        Object obj = new Object();
//        System.out.println(Integer.MAX_VALUE);
//        byte[] a = new byte[Integer.MAX_VALUE];
//        System.out.println(a.length);
    }

}
