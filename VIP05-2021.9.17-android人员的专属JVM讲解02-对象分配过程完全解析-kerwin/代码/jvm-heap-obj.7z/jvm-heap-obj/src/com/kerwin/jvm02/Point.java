package com.kerwin.jvm02;

public class Point {
    int x;
    int y;
    Object obj;

    //如哈希码（HashCode）、GC分代年龄、锁状态标志、线程持有的锁、偏向线程 ID、偏向时间戳\
    //32位数据容器，通过换算将不同意义的数字，落点到32位中的具体某些位上面
}
