package com.kerwin.jvm02;

public class TestGC {

    byte[] b = new byte[1024*300];
}
